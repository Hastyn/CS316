#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include <bits/stdc++.h>
class abstract_astnode
{
    public:
    virtual void print(int blanks) = 0;
    // enum typeExp astnode_type;
};

class exp_astnode : public abstract_astnode
{
    public:
    int type;
    std::string String;
    int offset;
    int deref=0;
    int dotted=0;
    exp_astnode* left;
    exp_astnode* right;
    exp_astnode* next;
    std::string structype;
    int lvalue;
    std::vector<exp_astnode*> exprlist;
    int intval;
    float floatval;
    std::string stringval;
    virtual void print(int blanks) = 0;
};

class statement_astnode : public abstract_astnode
{
    public:
    exp_astnode* ass_expr_one;
    exp_astnode* ass_expr_two;
    exp_astnode* expr;
    statement_astnode* stat;
    statement_astnode* stat2;
    std::vector<statement_astnode*> stats; 
    std::vector<exp_astnode*> expr_list; 
    std::string String;
    virtual void print(int blanks) = 0;
};

class empty_astnode : public statement_astnode
{
    void print(int blanks) override {
        printf("\"empty\"\n");
    }
};

class seq_astnode : public statement_astnode
{
    void print(int blanks) override {
        std::cout<<"{"<<std::endl;
        printf("\"seq\": [\n");
        for(unsigned int i=0;i<stats.size();i++)
        {
            // std::cout<<stats[i]->expr<<stats[i]<<std::endl;
            // std::cout<<sizeof(*stats[i]->print(0))<<std::endl;
            stats[i]->print(0);
            if (i!=stats.size()-1)
            std::cout<<","<<std::endl;
        }
        printf("]\n");
        std::cout<<"}"<<std::endl;
    }
};

class assignS_astnode : public statement_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"assignS\": { "<<std::endl;
        std::cout<<"\"left\": "<<std::endl;
        expr->left->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"right\": "<<std::endl;
        expr->right->print(0);
        std::cout<<"}\n}"<<std::endl;
        
     }
};

class return_astnode : public statement_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"return\": "<<std::endl;
        expr->print(0);
        std::cout<<"}\n"<<std::endl;
    }
};

class if_astnode : public statement_astnode
{
   void print(int blanks) override {
        // printf("body: empty\n");
        std::cout<<"{ \"if\": {"<<std::endl;
        std::cout<<"\"cond\":"<<std::endl;
        expr->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"then\":"<<std::endl;
        stat->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"else\":"<<std::endl;
        stat2->print(0);
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class while_astnode : public statement_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"while\": { \n\"cond\":"<<std::endl;
        expr->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"stmt\":"<<std::endl;
        stat->print(0);
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class for_astnode : public statement_astnode
{

    void print(int blanks) override {
        std::cout<<"{ \"for\": { \n\"init\":"<<std::endl;
        // std::cout<<ass_expr_one<<std::endl;
        ass_expr_one->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"guard\":"<<std::endl;
        expr->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"step\":"<<std::endl;
        ass_expr_two->print(0);
        std::cout<<",\n"<<std::endl;
        std::cout<<"\"body\":"<<std::endl;
        stat->print(0);
         std::cout<<"}"<<std::endl;
          std::cout<<"}"<<std::endl;
        // printf("body: empty\n");
    }
};

class proccall_astnode : public statement_astnode
{
    void print(int blanks) override {
         std::cout<<"{ \"proccall\": { "<<std::endl;
        std::cout<<"\"fname\": "<<std::endl;
        std::cout<<"{\n\"identifier\": \""<<String<<"\"\n}"<<std::endl;
        std::cout<<","<<std::endl;
        std::cout<<"\"params\": ["<<std::endl;
        for(unsigned int i=0;i<expr_list.size();i++)
        {
           expr_list[i]->print(0);
           if (i!=expr_list.size()-1)
           std::cout<<","<<std::endl;

        }
        printf("]\n");
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;

    }
};

class ref_astnode : public exp_astnode
{
    public:
    
    exp_astnode* leftchild;
    exp_astnode* rightchild;
    // identifier_astnode* iden;    
};

class op_binary_astnode : public exp_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"op_binary\": { "<<std::endl;
        std::cout<<"\"op\": \""<<String<<"\"\n,"<<std::endl;
        std::cout<<"\"left\": "<<std::endl;
        left->print(0);
        std::cout<<"\n,"<<std::endl;
        std::cout<<"\"right\": "<<std::endl;
        right->print(0);
        std::cout<<"\n}\n}"<<std::endl;

    }
};

class op_unary_astnode : public exp_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"op_unary\": { "<<std::endl;
        std::cout<<"\"op\": \""<<String<<"\"\n,"<<std::endl;
        std::cout<<"\"child\": "<<std::endl;
        next->print(0);
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class assignE_astnode : public exp_astnode
{
    void print(int blanks) override {
        // printf("body: empty\n");
        std::cout<<"{ \"assignE\": {"<<std::endl;
        std::cout<<"\"left\":"<<std::endl;
        left->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"right\":"<<std::endl;
        right->print(0);
        std::cout<<"}"<<std::endl;
         std::cout<<"}"<<std::endl;
    }
};

class funcall_astnode : public exp_astnode
{
     void print(int blanks) override {
        std::cout<<"{ \"funcall\": { "<<std::endl;
        std::cout<<"\"fname\": "<<std::endl;
        std::cout<<"{\n\"identifier\": \""<<String<<"\"\n}"<<std::endl;
        std::cout<<","<<std::endl;
        std::cout<<"\"params\": ["<<std::endl;
        for(unsigned int i=0;i<exprlist.size();i++)
        {   
            // std::cout<<stats[i]->expr<<stats[i]<<std::endl;
            // std::cout<<sizeof(*stats[i]->print(0))<<std::endl;
            exprlist[i]->print(0);
            if (i!=exprlist.size()-1)
            std::cout<<","<<std::endl;
        }
        std::cout<<"]"<<std::endl;
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class intconst_astnode : public exp_astnode
{
    void print(int blanks) override {
        std::cout<<"{\n\"intconst\": "<<intval<<"}"<<std::endl;
    }
};

class floatconst_astnode : public exp_astnode
{
    void print(int blanks) override {
        std::cout<<"{\n\"floatconst\": "<<floatval<<"}"<<std::endl;
    }
};

class stringconst_astnode : public exp_astnode
{
    void print(int blanks) override {
        std::cout<<"{\n\"stringconst\": "<<stringval<<"}"<<std::endl;
    }
};

class identifier_astnode : public ref_astnode
{
    void print(int blanks) override {
        // printf("body: empty\n");
        std::cout<<"{\n\"identifier\": \""<<String<<"\"\n}"<<std::endl;
    }
};

class arrayref_astnode : public ref_astnode
{
    void print(int blanks) override {
        std::cout<<"{ \"arrayref\": { "<<std::endl;
        std::cout<<"\"array\": "<<std::endl;
        leftchild->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"index\": "<<std::endl;
        rightchild->print(0);
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class member_astnode : public ref_astnode
{
    public:
    void print(int blanks) override {
        std::cout<<"{ \"member\": { "<<std::endl;
        std::cout<<"\"struct\": "<<std::endl;
        leftchild->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"field\": "<<std::endl;
        std::cout<<"{\n\"identifier\": \""<<String<<"\"\n}"<<std::endl;
        std::cout<<"}"<<std::endl;
         std::cout<<"}"<<std::endl;
    }
};

class arrow_astnode : public ref_astnode
{
     void print(int blanks) override {
        std::cout<<"{ \"arrow\": { "<<std::endl;
        std::cout<<"\"pointer\": "<<std::endl;
        leftchild->print(0);
        std::cout<<","<<std::endl;
        std::cout<<"\"field\": "<<std::endl;
        std::cout<<"{\n\"identifier\": \""<<String<<"\"\n}"<<std::endl;
        std::cout<<"}"<<std::endl;
        std::cout<<"}"<<std::endl;
    }
};

class data
{
    public:
    std::string funcname;
    int size;
};

class STE
{
    public:
    std::string name;
    std::string type;
    std::string scope;
    std::string returnType;
    std::string size;
    std::string offset;

    STE(std::string n,std::string t, std::string s, std::string sz, std::string o, std::string r)
    {
        name = n;
        type = t;
        scope = s;
        size = sz;
        offset = o;
        returnType = r;
    }
    STE()
    {
        name = "";
        type = "";
        scope = "";
        size = "";
        offset = "";
        returnType = "";
    }
};

class LST
{
    public:
    std::string name;
    std::vector<STE*> entries;
    abstract_astnode* ast;
    std::vector<std::string> param_check;

    LST(std::string n)
    {
        name = n;
    }

    void print(){
        std::cout<<"\"name\": \""<<name<<"\","<<std::endl;
        std::cout<<"\"localST\":\n";
        std::cout<<"[\n";
        std::sort(entries.begin(),entries.end(),[](STE* a,STE* b)->bool{ return (a->name<b->name); });
        for (unsigned int i=0;i<entries.size();i++)
        {
            std::cout<<"[\""<<entries[i]->name<<"\",\t\""<<entries[i]->type<<"\",\t\""<<entries[i]->scope<<"\",\t"<<entries[i]->size<<",\t"<<entries[i]->offset<<",\t\""<<entries[i]->returnType<<"\"\t"<<std::endl;
            std::cout<<"]\n"<<std::endl;

            if (i!=entries.size()-1)
            std::cout<<",";

        }
        std::cout<<"]\n";
        if(ast){
            std::cout<<",\n\"ast\":\n";
            ast->print(0);
            // std::cout<<"}"<<std::endl;
        }
    }
};

class GST
{
    public:
    std::vector<STE*> entries;
    std::vector<LST*> tables;

    void print()
    {
        std::sort(entries.begin(),entries.end(),[](STE* a,STE* b)->bool{ return (a->name<b->name); });
        std::cout<<"{\"globalST\":\n[";
        for (unsigned int i=0;i<entries.size();i++)
        {
            std::cout<<"[\""<<entries[i]->name<<"\",\t\""<<entries[i]->type<<"\",\t\""<<entries[i]->scope<<"\",\t"<<entries[i]->size<<",\t"<<entries[i]->offset<<",\t\""<<entries[i]->returnType<<"\"\t"<<std::endl;
            std::cout<<"]";
            if (i!=entries.size()-1)
            std::cout<<",";

            std::cout<<std::endl;
        }
        std::cout<<"]\n,\n";

        std::vector<LST*> structs;
        std::vector<LST*> funcs;

        for (unsigned int i=0;i<tables.size();i++)
        {
            if(tables[i]->ast){
               funcs.push_back(tables[i]);
            }
            else{
               structs.push_back(tables[i]);
            }   
        }
        std::sort(structs.begin(),structs.end(),[](LST* a,LST* b)->bool{ return (a->name<b->name); });
        std::cout<<"\"structs\": [\n";
        for (unsigned int i=0;i<structs.size();i++)
        { 
            std::cout<<"{\n";
            structs[i]->print();
            std::cout<<"}\n";
            if (i!=structs.size()-1)
            std::cout<<","<<std::endl;         
        }
        std::cout<<"],\n";

        std::sort(funcs.begin(),funcs.end(),[](LST* a,LST* b)->bool{ return (a->name<b->name); });
        std::cout<<"\"functions\": [\n";
        for (unsigned int i=0;i<funcs.size();i++)
        {   
            std::cout<<"{\n";
            funcs[i]->print();
            std::cout<<"}\n";
            if (i!=funcs.size()-1)
            std::cout<<","<<std::endl;
        }
        std::cout<<"]\n}";
    }
};

class base_type 
{
    public:
    int ptr_depth,size;
    std::string name,type;
};
